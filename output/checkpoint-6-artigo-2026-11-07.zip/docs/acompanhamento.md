# Acompanhamento — roteiro atualizado até o Checkpoint 6

Estado: roteiro de andamento; não comprova criação/entrega dos slides nem apresentação.
Alvo: NU_NOTA_CN. Repositório: https://github.com/JoeyAlanS/trab2-aprendizado-de-maquina
Autores: Joey Alan de Freitas Solis e Paulo Henrico. Unifor; professor Tulio.
Distribuição das falas e ensaio pertencem ao Checkpoint 7.

| Slide | Conteúdo e evidência |
|---|---|
| 1. Problema | Quanto perfil socioeconômico, escolar e demográfico permite estimar CN? |
| 2. Base | 3.933.955 linhas, 76 colunas; 2.692.427 elegíveis; alvo ausente não é zero |
| 3. Protocolo | 2.153.941 desenvolvimento, 538.486 teste final; seed 42 e três dobras |
| 4. Entradas | Q005 e 39 categóricas; transformações no treino e bloqueios de vazamento |
| 5. Comparação inicial | Média ~87,92; linear/Ridge ~76,48; árvore ~77,17 de RMSE; apresentar DP e tempos do CSV real |
| 6. Avanços e próximas etapas | Checkpoints 1–6 concluídos; Stacking RMSE teste 76,190; originais conferidos e artigo finalizado; faltam os dois PDFs do Checkpoint 7 |

Usar a figura de distribuição dos agregados reais e a comparação inicial verificada.
Os sete modelos do Checkpoint 1 estão em [checkpoint-1-resultados.md](checkpoint-1-resultados.md),
com 21 avaliações e três figuras verificadas. Isso não substitui a preparação dos slides.
A seleção de Stacking, SVM linear e Random Forest entre os sete está documentada no
[Checkpoint 2](checkpoint-2-resultados.md), com a diferença para o catálogo ampliado explícita.
Linear e Ridge têm diferenças muito pequenas frente à variação entre dobras: isso não
permite concluir que a multicolinearidade é moderada ou que a regularização é inútil.
Identificar claramente os resultados de desenvolvimento e de teste ao atualizar o acompanhamento. Não usar figuras/números arquivados
como não validados. Exportar slides em docs/acompanhamento.pdf e conferir o prazo no AVA.

As curvas do trio estão concluídas no [Checkpoint 3](checkpoint-3-resultados.md):
45 ajustes, cinco tamanhos e três dobras. O Stacking apresentou o menor RMSE médio
nos cinco tamanhos. O [Checkpoint 4](checkpoint-4-resultados.md) concluiu buscas,
curvas finais e avaliação do teste: Stacking teve RMSE 76,190 e redução de 13,38%
frente ao baseline, com erros maiores nos extremos das notas. As figuras PNG/SVG
estão disponíveis no relatório, sem substituir a preparação e a entrega do PDF.
