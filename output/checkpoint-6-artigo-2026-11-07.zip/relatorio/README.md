> A versão de entrega atual é o [artigo do Checkpoint 6](../output/pdf/artigo_ciencias_natureza.pdf), com dez páginas. Os arquivos LaTeX desta pasta são versões anteriores e foram preservados. Reprodução da versão atual: [Checkpoint 6](../docs/checkpoint-6-resultados.md).

# Relatório de Ciências da Natureza no ENEM 2023

Projeto LaTeX editável com `main.tex`, `images/` e `tables/`. A narrativa pode ser
editada sem alterar os resultados científicos. As figuras e tabelas são geradas
por `scripts/gerar_relatorio.py`, a partir de snapshots verificados.

O PDF histórico local fica em `output/pdf/relatorio_ciencias_natureza.pdf` na raiz do
projeto de código. A versão de 23/10/2026 tem dez páginas, com 40 relações com CN,
780 pares de entradas e os resultados iniciais já existentes de validação cruzada.
Esse documento retrata a fase em que o teste ainda estava reservado; não é o artigo final completo.
Ele não incorpora os resultados posteriores dos sete algoritmos, disponíveis em
[Checkpoint 1](../docs/checkpoint-1-resultados.md), nem o teste final do
[Checkpoint 4](../docs/checkpoint-4-resultados.md). A atualização do artigo/PDF final
permanece para os checkpoints de documentação.

Para compilar apenas esta pasta, use `tectonic main.tex`, XeLaTeX ou o editor
LaTeX do Codex. Para regenerar dados e compilar a partir da raiz do projeto de
código, use `scripts/compilar_relatorio.ps1`.

Os autores ainda precisam ser informados. O repositório confirmado é
https://github.com/JoeyAlanS/trab2-aprendizado-de-maquina.
O pacote Overleaf foi reconstruído com o material preliminar verificável; a versão
anterior com resultados sem execução está preservada em `historico/2026-11-05/`.
`relatorio_final.tex` agora encaminha para `main.tex` e não declara um artigo final concluído.
