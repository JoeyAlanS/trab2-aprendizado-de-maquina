# Relatório preliminar, não artigo final

Este pacote reúne somente o relatório de desenvolvimento e seus agregados históricos verificáveis.
As versões com métricas fixas/simuladas foram preservadas em historico/2026-11-05/artefatos-nao-validados.zip e não fazem parte deste pacote.
Ainda faltam a comparação científica completa, a seleção e a avaliação final, autores e slides.
Consulte o README do projeto e docs/relatorio-correcao-2026-11-05.md para o estado atual.
