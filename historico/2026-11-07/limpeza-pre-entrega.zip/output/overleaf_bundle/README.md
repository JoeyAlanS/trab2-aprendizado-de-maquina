# Relatório de Ciências da Natureza no ENEM 2023

Projeto LaTeX editável com `main.tex`, `images/` e `tables/`. A narrativa pode ser
editada sem alterar os resultados científicos. As figuras e tabelas são geradas
por `scripts/gerar_relatorio.py`, a partir de snapshots verificados.

O PDF entregue fica em `output/pdf/relatorio_ciencias_natureza.pdf` na raiz do
projeto de código. A versão de 23/10/2026 tem dez páginas, com 40 relações com CN,
780 pares de entradas e os resultados iniciais já existentes de validação cruzada.
É um relatório de desenvolvimento com teste reservado, não o artigo final completo.

Para compilar apenas esta pasta, use `tectonic main.tex`, XeLaTeX ou o editor
LaTeX do Codex. Para regenerar dados e compilar a partir da raiz do projeto de
código, use `scripts/compilar_relatorio.ps1`.

Os autores ainda precisam ser informados. O repositório confirmado é
https://github.com/JoeyAlanS/trab2-aprendizado-de-maquina.
O pacote Overleaf foi reconstruído com o material preliminar verificável; a versão
anterior com resultados sem execução está preservada em `historico/2026-11-05/`.
`relatorio_final.tex` agora encaminha para `main.tex` e não declara um artigo final concluído.
